import re

import requests
from django.db.models import Q
from django.shortcuts import render
from rest_framework import generics

from .models import *
from .serializers import *
from .permissions import *
from rest_framework.response import Response
from rest_framework.views import APIView
from .pagination import *
import pyclick
from rest_framework.permissions import IsAuthenticated
# Create your views here.


class RegisterView(APIView):

    authentication_classes = []

    def post(self, request):
        serializer = UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data)


# class LogoutView(APIView):
#     permission_classes = [IsAuthenticated, ]
#
#     def post(self, request):
#         response = Response()
#         # response.delete_cookie('jwt')
#         refresh_token = request.data['refresh']
#         token = RefreshToken(refresh_token)
#         token.blacklist()
#
#         response.data = {
#             'message': 'success'
#         }
#         return response


class UserAPIGet(APIView):
    # queryset = User.objects.all()
    # serializer_class = UserSerializer
    # permission_classes = [IsAuthenticated, ]

    def get(self, request):
        # user = User.objects.get(pk=request.user.id)
        return Response({
            'id': request.user.id,
            'phone': request.user.phone,
            'name': request.user.name,
            'email': request.user.email,
            'photo': request.user.photo,
            'role': request.user.role.name,
            'role_en': request.user.role.name_en
        })


class UserAPIGetAll(generics.ListAPIView):

    def get_queryset(self):
        search = ''
        if self.request.query_params.get('search'):
            search += self.request.query_params.get('search')
        if int(self.request.query_params.get('role_id')) == -1:
            return User.objects.filter(Q(
                name__icontains=search) | Q(email__icontains=search) | Q(phone__icontains=search))
        else:
            return User.objects.filter(Q(role_id=int(self.request.query_params.get('role_id'))) & (Q(
                name__icontains=search) | Q(email__icontains=search) | Q(phone__icontains=search)))

    serializer_class = UserSerializer
    permission_classes = [IsAdmin, ]
    pagination_class = UserPagination


class AdminUserAPIDelete(generics.DestroyAPIView):
    queryset = User.objects.all()
    permission_classes = [IsAdmin, ]


class AdminUserAPIUpdate(generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = AdminUserUpdateSerializer
    permission_classes = [IsAdmin, ]


class AdminSupportAPIGet(generics.ListAPIView):
    def get_queryset(self):
        search = ''
        if self.request.query_params.get('search'):
            search += self.request.query_params.get('search')
        status = self.request.query_params.get('status')
        if status == 'all':
            return Support.objects.filter(description__icontains=search)
        elif status == 'solved':
            return Support.objects.filter(solved=True, description__icontains=search)
        elif status == 'unsolved':
            return Support.objects.filter(solved=False, description__icontains=search)
        else:
            return None
    pagination_class = SupportPagination
    serializer_class = SupportSerializer
    permission_classes = [IsAdmin, ]




class SupportAPICreate(generics.CreateAPIView):
    queryset = Support.objects.all()
    serializer_class = SupportSerializer
    permission_classes = [IsCustomer, ]


class SupportAPIUpdate(APIView):
    permission_classes = [IsAdmin, ]

    def patch(self, request, pk):
        support = Support.objects.filter(id=pk).first()
        support.solved = request.data.get('solved')
        support.save()
        return Response({'message': 'success'})


class FeedbackAPICanCreate(APIView):
    permission_classes = [IsCustomer, ]

    def get(self, request, pk):
        item = Movie.objects.get(pk=pk)
        items_ids = [order_item.item.id for order_item in Ticket.objects.filter(session__in=Session.objects.filter(
            user=request.user, delivered_at__isnull=False))]
        if item.id in items_ids:
            return Response({'message': 'success'})
        raise ValidationError("You can't leave a feedback because you haven't purchased this item yet")


class FeedbackAPICreate(APIView):
    permission_classes = [IsCustomer, ]

    def post(self, request):
        feedback_data = request.data
        Feedback.objects.create(item_id=feedback_data['item_id'], description=feedback_data[
            'description'], user=request.user, rating=feedback_data['rating'])
        movie = Movie.objects.get(id=feedback_data['item_id'])
        movie.rating = Feedback.objects.filter(movie=movie).aggregate(Movie('rating'))['rating__avg']
        movie.save()
        return Response({"message": "feedback was successfully created"})


class AdminFeedbackAPIGetAll(generics.ListAPIView):
    def get_queryset(self):
        search = ''
        if self.request.query_params.get('search'):
            search += self.request.query_params.get('search')
        status = self.request.query_params.get('status')
        if status == 'published':
            return Feedback.objects.filter(publish=True, description__icontains=search)
        elif status == 'unpublished':
            return Feedback.objects.filter(publish=False, description__icontains=search)
        else:
            return Feedback.objects.all()

    serializer_class = FeedbackSerializer
    permission_classes = [IsAdmin, ]
    pagination_class = FeedbackPagination


class AdminFeedbackAPIUpdate(generics.UpdateAPIView):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer
    permission_classes = [IsAdmin, ]


class HallAPIGetALL(generics.ListAPIView):
    queryset = Hall.objects.all()
    serializer_class = HallSerializer
    permission_classes = [IsCustomer, ]


class MovieAPIGetAll(generics.ListAPIView):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer


class SessionAPICreate(APIView):
    permission_classes = [IsSalesman, ]

    def post(self, request):
        data = request.data
        session_serializer = SessionSerializer(request.data)
        session_serializer.is_valid(raise_exception=True)
        session = Session.objects.create(movie_id=data['movie_id'], hall_id=data['hall_id'], time=data['time'],
                                         price=data['price'])

        # hall = Hall.objects.get(hall_id=data['hall_id'])
        #
        # for i in range(hall.rows):
        #     for j in range(hall.seats):
        #         Ticket.objects.create(session=session, row=i+1, seat=j+1)
        return Response({'session': SessionSerializer(session).data})


class SessionAPIGet(generics.RetrieveAPIView):
    queryset = Session.objects.all()
    serializer_class = SessionSerializer
    authentication_classes = []


class SessionAPIDelete(generics.DestroyAPIView):
    queryset = Session.objects.all()
    permission_classes = [IsSalesman, ]


class TicketAPICreate(APIView):
    permission_classes = [IsCustomer, ]

    def post(self, request):
        d = request.data
        Ticket.objects.create()
        if Ticket.objects.filter(session_id=d['session_id'], row=d['row'], seat=d['seat']):
            raise ValidationError("Такое место уже есть")
        # transaction = ClickTransaction.objects.create(amount=Session.objects.get(id=d['session_id']).price)
        ticket = Ticket(session_id=d['session_id'], row=d['row'], seat=d['seat'], status=1, owner=request.user)
        # ticket.transaction = transaction
        # phone_num = re.sub('[ +\-()]', '', d['phone'])
        # requests.post('http://127.0.0.1:8000/pyclick/process/click/service/create_invoice',
        #               {'phone_number': phone_num, 'transaction_id': transaction.id})
        ticket.save()
        return Response({'message': 'success'})


class TicketAPIUpdate(APIView):
    permission_classes = [IsSalesman, ]

    def post(self, request, pk):
        status = request.data['status']
        if not (0 <= status <= 2):
            raise ValidationError('wrong status')
        ticket = Ticket.objects.get(id=pk)
        ticket.status = status
        ticket.editor = request.user

        return Response({'message': 'success'})


class TicketAPIDelete(APIView):

    def delete(self, request, pk):
        ticket = Ticket.objects.get(id=pk)
        if request.user != ticket.owner:
            return Response({'message': 'Тебе сюда низя'})
        if ticket.transaction.status == 'confirmed':
            requests.post('http://127.0.0.1:8000/pyclick/process/click/service/cancel_payment',
                          {'transaction_id': ticket.transaction.id})
            ticket.delete()
            return Response({'message': 'success'})
        else:
            raise ValidationError('hahaha')


class NewsAPIGetAll(generics.ListAPIView):
    queryset = News.objects.all()
    serializer_class = NewsSerializer
    authentication_classes = []
    pagination_class = NewsPagination


class NewsAPICreate(generics.CreateAPIView):
    queryset = News.objects.all()
    serializer_class = NewsSerializer
    permission_classes = [IsAdmin, ]


class NewsAPIUpdate(generics.UpdateAPIView):
    queryset = News.objects.all()
    serializer_class = NewsSerializer
    permission_classes = [IsAdmin, ]


class NewsAPIDelete(generics.DestroyAPIView):
    queryset = News.objects.all()
    permission_classes = [IsAdmin, ]
