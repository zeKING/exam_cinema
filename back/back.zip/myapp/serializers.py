from rest_framework import serializers
from .models import *

from rest_framework import serializers
from .models import *
import base64


class UserSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=64)
    password = serializers.CharField(max_length=255, write_only=True)
    email = serializers.EmailField()
    photo = serializers.ImageField(required=False)
    photo_base64 = serializers.CharField(source='photo', read_only=True)
    role_id = serializers.IntegerField()
    role = serializers.CharField(read_only=True)
    phone = serializers.CharField()

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        photo_file = validated_data.pop('photo', None)

        instance = User(**validated_data)
        instance.role = Role.objects.get(name='Пользователь')
        if photo_file:
            photo_type = str(photo_file).split('.')[-1]
            photo = base64.b64encode(photo_file.read())
            photo_text = f'data:image/{photo_type};base64,' + photo.decode()
            instance.photo = photo_text
        if password is not None:
            instance.set_password(password)

        instance.save()
        return instance


class AdminUserUpdateSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=64, required=False)
    photo = serializers.ImageField(required=False)
    role_id = serializers.IntegerField(required=False)

    def update(self, instance, validated_data):
        instance.name = validated_data.get("name", instance.name)
        instance.photo = validated_data.get('photo', instance.photo)
        instance.role_id = validated_data.get('role_id', instance.role_id)

        instance.save()
        return instance

class SupportSerializer(serializers.ModelSerializer):

    def get_file_url(self, obj):
        return obj.get_file_url()
    user_id = serializers.IntegerField(read_only=True)

    file_url = serializers.SerializerMethodField()
    user_name = serializers.CharField(source='user.name', read_only=True)
    user_phone = serializers.CharField(source='user.phone', read_only=True)

    class Meta:
        model = Support
        fields = ('id', 'description', 'created_at', 'file', 'file_url', 'user_id', 'user_name',
                  'user_phone', 'solved')
        extra_kwargs = {
            'file': {'write_only': True}
        }

    def create(self, validated_data):
        description = validated_data.get('description')
        file = validated_data.get('file')
        item = Support.objects.create(description=description, file=file, user=self.context['request'].user)

        item.save()
        return item


class FeedbackSerializer(serializers.ModelSerializer):
    movie_id = serializers.IntegerField()
    movie_name = serializers.CharField(source='item.name', read_only=True)
    user_name = serializers.CharField(source='user.name', read_only=True)

    class Meta:
        model = Feedback
        fields = ('id', 'movie_id', 'movie_name', 'description', 'created_at', 'user_name', 'rating', 'publish')
        extra_kwargs = {
            'user': {'read_only': True}
        }

    def update(self, instance, validated_data):
        instance.publish = validated_data.get('publish')
        instance.save()
        return instance


class SessionSerializer(serializers.ModelSerializer):
    movie_name = serializers.CharField(source='movie.name', read_only=True)
    hall_name = serializers.CharField(source='hall.name', read_only=True)
    movie_id = serializers.IntegerField()
    hall_id = serializers.IntegerField()

    class Meta:
        model = Session
        fields = ['id', 'movie_id', 'movie_name', 'hall_id', 'hall_name', 'time', 'price']


class HallSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hall
        field = '__all__'


class TicketSerializer(serializers.ModelSerializer):
    session_time = serializers.DateTimeField(source='session.time')

    class Meta:
        model = Ticket
        field = ['id', 'created_at', 'session_time', 'row', 'seat', 'status', ]


class NewsSerializer(serializers.ModelSerializer):
    photo_url = serializers.CharField(source='photo.url', read_only=True)

    class Meta:
        model = News
        fields = ('id', 'title', 'description', 'photo', 'photo_url', 'created_at')
        extra_kwargs = {
            'photo': {'write_only': True}
        }

    def create(self, validated_data):
        new = News(**validated_data)
        new.save()
        return new

    def update(self, instance, validated_data):
        instance.title = validated_data.get('title', instance.title)
        instance.description = validated_data.get('description', instance.description)
        instance.photo = validated_data.get('photo', instance.photo)
        instance.save()
        return instance


class MovieSerializer(serializers.ModelSerializer):

    class Meta:
        model = Movie
        fields = ['name', 'desctiption', 'duration', 'age_limit']
